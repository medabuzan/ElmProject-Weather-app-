module View.Week exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class)
import List
import Util
import Util.Time
import View.Day exposing (DailyData)


type alias WeeklyData =
    { dailyData : List DailyData
    }


{-| Generates Html based on `WeeklyData`

Some relevant functions:

  - `Util.Time.formatDate`

-}



view : WeeklyData -> Html msg
view data =
    let
        firstDay = List.head data.dailyData |> Maybe.map (\day -> Util.Time.formatDate day.date) |> Maybe.withDefault "none"
        lastDay = Util.last data.dailyData |> Maybe.map (\day -> Util.Time.formatDate day.date) |> Maybe.withDefault "no"
    in
        if List.isEmpty data.dailyData then
            div [class "week"] [
                h2 [] [text "None"]
            ]
        else
            div [class "week"] ([
                h2 [] [
                 "First day: " ++ firstDay  ++ "  Last day: " ++ lastDay |> text
                ]
            ]
            ++ List.map (\d -> View.Day.view d) data.dailyData)