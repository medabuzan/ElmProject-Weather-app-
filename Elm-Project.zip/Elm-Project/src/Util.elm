module Util exposing (groupBy, maximumBy, maybeToList, minimumBy, zipFilter, last)

{-| Module containing utility functions
-}


{-| Description for minimumBy

    minimumBy .x [ { x = 1, y = 2 } ] --> Just {x = 1, y = 2}

    minimumBy .x [] --> Nothing

    minimumBy (modBy 10) [ 16, 23, 14, 5 ] --> Just 23

-}
minimumBy : (a -> comparable) -> List a -> Maybe a
minimumBy pred list =
  if list == [] then
    Nothing
  else
    list
        |> List.sortBy pred
        |> List.head
    --Debug.todo "Implement Util.minimumBy"


{-| Description for maximumBy

    maximumBy .x [ { x = 1, y = 2 } ] --> Just {x = 1, y = 2}

    maximumBy .x [] --> Nothing

    maximumBy (modBy 10) [ 16, 23, 14, 5 ] --> Just 16

-}
maximumBy : (a -> comparable) -> List a -> Maybe a
maximumBy pred list  =
     if list == [] then
      Nothing
     else
        list
            |> List.sortBy pred
            |> last


last: List a -> Maybe a
last ls =
    case ls of
        [] -> Nothing
        [x] -> Just x
        _::xs -> last xs


duplicates : List a -> List a
duplicates l = 
    let
        incduplicates : a -> List a -> List a
        incduplicates current list = 
            case List.member current list of
                True -> list
                False -> current :: list
    in
        List.foldr incduplicates [] l

{-| Group a list

    groupBy .x [ { x = 1 } ] --> [(1, [{x = 1}])]

    groupBy (modBy 10) [ 11, 12, 21, 22 ] --> [(1, [11, 21]), (2, [12, 22])]

    groupBy identity [] --> []

-}
groupBy : (a -> b) -> List a -> List ( b, List a )
groupBy pred list =
    let
        index =( (List.map pred) >> duplicates ) list
        aux var1 var2   =
            case var1 of
                [] -> []
                x::xs -> (x,List.filter(\a -> pred a == x) var2) :: aux xs var2
    in
        aux index list

{-| Transforms a Maybe into a List with one element for Just, and an empty list for Nothing

    maybeToList (Just 1) --> [1]

    maybeToList Nothing --> []

-}
maybeToList : Maybe a -> List a
maybeToList var =
    case var of
        Just x -> [x]
        Nothing -> []


{-| Filters a list based on a list of bools

    zipFilter [ True, True ] [ 1, 2 ] --> [1, 2]

    zipFilter [ False, False ] [ 1, 2 ] --> []

    zipFilter [ True, False, True, False ] [ 1, 2, 3, 4 ] --> [1, 3]

-}
zipFilter : List Bool -> List a -> List a
zipFilter lbool lelem =
    let
        pair = List.map2 Tuple.pair lbool lelem
    in
        ( (List.filter (\(x,_)-> x == True)) >> (List.unzip) >> (Tuple.second)  ) pair    
